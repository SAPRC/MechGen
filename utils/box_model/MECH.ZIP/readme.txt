SAPRC CHEMICAL MECHANISMS, TEST SIMULATIONS, AND
ENVIRONMENTAL CHAMBERSIMULATION FILES

William P. L. Carter
College of Engineering Center for
Environmental Research and Technology
University of California
Riverside, CA 92521
Email: carter@cert.ucr.edu

June 25, 2012

See SAPRCfiles.pdf for more information and instructions on
installing these files. Additional files and documentation are
available at http://www.cert.ucr.edu/~carter/SAPRC/SAPRCfiles.htm.

Summary

This distribution contains files documenting and implementing the
versions of the SAPRC gas-phase atmospheric chemical mechanisms
and the files and programs necessary simulate the environmental
chamber experiments used to evaluate the detailed mechanism, and
to run the test calculations used to develop and evaluate the
condensed SAPRC-07 mechanisms. Files and programs to calculate the
reactivity scales or simulate the reactivity scenarios are also
included in this distribution. The distributed files are as
follows:

- MECH.ZIP contains the files implementing the various versions of
  the SAPRC mechanisms.  Note that the public-domain GNU fortran
  (gfortran) must be installed and its binaries must be on the
  path if you want to run simulations with new or modified
  mechanisms.

- PGMS.ZIP contains the SAPRC modeling programs needed to run the
  environmental chamber simulations and the test calculations. The
  source files, which can be compiled using the public-domain GNU
  fortran (gfortran) are also included, along with batch files to
  compile and link the programs.

- TESTCALC.ZIP contains the files needed to run the static and
  multi-day dynamic test calculations discussed in the condensed
  mechanism documentation report of Carter (2007b).

- CHAMCALC.ZIP contains the files necessary to use the distributed
  mechanisms and software to evaluate the mechanisms against
  a selected subset of the chamber data.

- CHAMEXPT.ZIP contains the input and data files for most of the
  chamber experiments used in SAPRC mechanism evaluations reported
  as of June, 2012.  Files in CHAMCALC.ZIP are also needed to
  simulate these experiments.  The files in CHAMEXPT.ZIP that are
  not in CHAMCALC.ZIP are not needed to run the example
  calculations.

- REACT.ZIP contains all the input and data files need to run a
  complete reactivity scale simulation using the SAPRC-07
  mechanism. This is the latest version of the SAPRC reactivity
  scales currently available.

- UNZIP.EXE is a freeware unzip program by Info-Zip
  (http://www.info-zip.org/) that can be used to extract the .ZIP
  files if the user does not already have such a program.

- MINGF.ZIP contains the minimum set of dynamic link library
  (.DLL) files needed so that the compiled programs in the
  distribution will run without GNU MinGW gfortran being
  installed. Note that these are not sufficient to compile new or
  modified mechanisms or change any of the programs. DO NOT
  INSTALL THESE FILES IF YOU HAVE, OR PLAN TO HAVE, MINGW AND
  GFORTRAN INSTALLED!

See SAPRCfiles.pdf for more information and instructions on how
to use these files.  Brief instructions are as follows:

To install:
- Download the ZIP files and UNZIP.EXE into an empty folder with
  at least 200 MB or more and unzip them using UNZIP.EXE without
  any parameters. If you unzip them a different way, be sure to
  do so in a way that preserves the directory structure as
  indicated in SAPRCfiles.pdf.

- Edit NEWENV.BAT and change the "SET TMPENV=(whatever)" to
  point to the directory name where you unzipped the files.
  E.g., the full path name of NEWENV.BAT should be
  %NEWENV%\NEWENV.BAT

To Use:
- Open a DOS box, go to the folder where you installed the files,
  and run NEWENV.BAT (after editing it as indicated above).  If
  you get an "out of environment space" message, you need to fix
  your DOS environment.

- Go to the CHAMCALC folder to run the chamber simulations.  See
  EXAMPLE.BAT for examples.

- Go to the TESTCALC folder to run the mechanism comparison test
  calculations. See EXAMPLE.BAT for examples.

- Go to the REACT folder and run the example reactivity
  calculations in REACTEX.BAT.

Also included are Excel templates that can be used to display
plots of results of chamber simulations and chamber data.
Examples of spreadsheets using these templates are also included.
These are not documented but have comments in the files that
should assist in how to use them. The included templates, and
example files created from them, are as follows:

- RunCalc.xlt -- shows plots of data and several model
  calculations for one or two experiments.  An example of a file
  created from this is CHAMCALC\RunCalcEx.xls.  Change cell "I30"
  to point to the root folder where the files are distributed
  (i.e., the same as what you set for the TMPENV environment
  variable in NEWENV.BAT.

- RunsFit.xlt -- shows plots of data and several model
  calculations for multiple experiments.  Examples of files
  created from this are CHAMCALC\RunsFitEx.xls and
  TESTCALC\TestCalcs.xls. In all change cell "B35" to point to the
  root folder where the files are distributed.  You will also need
  to change "B36" to point to the location of the test
  calculations if you are using this for calculations in TESTCALC
  (see Testcalcs.xls).

- RunFitPlt.xlt -- this is used by RunsFit.xlt and files created
  from it.  It is not for creating separate spreadsheets.

These programs, examples and templates are not yet documented,
but documentation is being prepared as part of an ongoing project.
Please contact William P. L. Carter for comments and questions.

William P. L. Carter
CE-CERT, University of California, Riverside CA 92521
951 781-5797 or 951 788-8425
carter@cert.ucr.edu
http://www.cert.ucr.edu/~carter
